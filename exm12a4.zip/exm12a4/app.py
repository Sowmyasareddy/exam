from flask import Flask,render_template
app=Flask(__name__)
@app.root('\')
def home():
	return render_template('web.html')
if __name__=='__main__':
	app.run(deploy=True)